/**
 * Provides JUnit test cases for {@link backend}
 * @author hoo42
 * @author rvo16
 */
package backendTesting;