/**
 * Provides a GUI implementation of a space explorers game
 * @author hoo42
 * @author rvo16
 */
package graphicalInterface;