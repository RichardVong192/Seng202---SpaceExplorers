/**
 * Provides necessary classes to extend {@link backend} for use with a GUI
 * @author hoo42
 * @author rvo16
 */
package backendGUIExtensions;