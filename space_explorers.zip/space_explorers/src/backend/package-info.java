/**
 * Provides necessary classes to create a functioning backend for a space explorers game
 * @author hoo42
 * @author rvo16
 */
package backend;