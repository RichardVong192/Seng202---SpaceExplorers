/**
 * Provides the game environment for running a space explorers game through a CLI
 * @author hoo42
 * @author rvo16
 */
package commandLine;